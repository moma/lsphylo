import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import scala.reflect.ClassTag
import scala.math
import scala.math.Ordering

object Create {

  val conf = new SparkConf().setAppName("Louvain (Create)").setMaster("spark://132.227.199.101:7077").set("spark.default.parallelism", "250")
  val sc = new SparkContext(conf)
  
  def stripChars(s:String, ch:String)= s filterNot (ch contains _)

  val fairness = sc.textFile("cooc/fairness/fairness_1990").map(l => (stripChars(l.split(',')(0), "u'"), (stripChars(l.split(',')(1), "u'"), l.split(',')(3).toDouble))).cache()

  val w = sc.textFile("cooc/output/cooc_1990").map(l=> ((stripChars(l.split(',')(0), "u' ()"), stripChars(l.split(',')(1), "u' ()")), stripChars(l.split(',')(2), "u' ()").toInt)).cache()

  val indexi  = sc.textFile("cooc/index").map(v => ( v.split(',')(0), v.split(',')(1).toLong )).cache()

  def create( seuil : Int) = {
	  val f = fairness.filter(v => math.abs(math.log10(v._2._2)) < seuil.toDouble).map(v => (v._1, v._2._1))
	  val sf = f.groupByKey().map(v => (v._1, v._1))
	  val usf = f.filter(v => v._1 > v._2).union(sf).map(v => ((v._1,v._2),1.0))
	  val uswf = usf.join(w).map(v => (v._1._1, (v._1._2, v._2._2)))
	  val uswi = uswf.join(indexi).map(v => (v._2._1._1, (v._2._2, v._2._1._2))).join(indexi).map(v => ((v._2._1._1, v._2._2), v._2._1._2)).cache()
	  uswi.map(v => v._1._1.toString + " " + v._1._2.toString + " " + v._2.toString).saveAsTextFile("cooc/louvain/input/1990/" + seuil.toString + "usw")
	  val uwi = uswi.filter(v =>  v._1._1 != v._1._2).cache()
	  uwi.map(v => v._1._1.toString + " " + v._1._2.toString + " " + v._2.toString).saveAsTextFile("cooc/louvain/input/1990/" + seuil.toString + "uw")
	  uwi.map(v => v._1._1.toString + " " + v._1._2.toString).saveAsTextFile("cooc/louvain/input/1990/" + seuil.toString + "u")
	  // uswi.map(v => v._1._1.toString + " " + v._1._2.toString).saveAsTextFile("cooc/louvain/input/1990/" + seuil.toString + "us")
  }
  
  def main(args: Array[String]): Unit = {
    create(1)
    create(2)
    create(3)
  }
}