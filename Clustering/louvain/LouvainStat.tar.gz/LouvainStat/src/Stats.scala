import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import scala.reflect.ClassTag
import scala.math
import scala.math.Ordering

object Stats {
  
  
  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setAppName("Louvain (Stats)").setMaster("spark://132.227.199.101:7077").set("spark.default.parallelism", "250")
    val sc = new SparkContext(conf)
      
    val v = args(0)
	val inputt = sc.textFile("cooc/louvain/input/1990/" + v).map(l => (l.split(" ")(0), l.split(" ")(1))).groupByKey().map(v => (v._1, 1))
	val res = sc.textFile("cooc/louvain/output/" + v + ".data.comm").map(l => (l.split(" ")(0), l.split(" ")(1))).join(inputt).map(v => (v._1.toLong, v._2._1.toLong)).cache()

    val stats = res.map(v => (v._2, 1.0)).reduceByKey(_ + _).map(v => v._2).stats()
    println(stats)

    val index = sc.textFile("cooc/index").map(v => (v.split(',')(1).toLong , v.split(',')(0))).cache()
    val get = sc.textFile("cooc/terms").map(v => ( v.split('|')(0), v.split('|')(1) )).cache()

    res.join(index).map(v => (v._2._2, v._2._1)).join(get).map(v => (v._2._1, v._2._2)).groupByKey()
       .saveAsTextFile("cooc/louvain/output/"+v)
  }

}